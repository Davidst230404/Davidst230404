# Setup

1. Upload this package into the special profile repository `Davidst230404`.
2. Make sure these paths exist:
   - `.github/workflows/github-stats.yml`
   - `profile/stats.svg`
   - `profile/top-langs.svg`
3. Open **Actions → Update GitHub Profile Stats → Run workflow** once manually.
4. Wait for the workflow to finish. It will generate the SVG files and commit them to the repository.
5. Refresh the GitHub profile README.

The workflow uses GitHub's built-in `GITHUB_TOKEN` and GitHub REST API. It does not use `github-readme-stats.vercel.app` or `github-readme-activity-graph.vercel.app`.

The contribution calendar itself remains native to GitHub and appears below the profile README.
